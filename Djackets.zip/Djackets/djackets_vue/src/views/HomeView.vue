<template>
  <div class="home">
    <section class = "hero is-medium is-dark mb-6">
      <div class="hero-body has-text-centered">
        <p class="title mb-6">
          WELCOME TO DJACKETS
        </p>
        <p class="subtitle mb-6">
          The best jacket store online
        </p>
      
      </div>
    </section>

    <div class = "columns is-multiline">
      <div class="column is-12">
          <h1 class="is-size-10 has-text-centered">Latest Product</h1>
         
      </div>

      <div class="column is-2" 
       v-for="product in latestProducts"
         v-bind:key="product.id">
      <div class="box">
        <figure class="image mb-4">
          <img :src="product.get_thumbnail">
        </figure>

       <h3 class="is-size-4">{{ product.name }}</h3>
       <p class="is-size-6 has-text-grey">${{ product.price }}</p>

        View Details
     
      </div>
      </div>
    </div>

  </div>
</template>

<script>

import axios from 'axios'

export default {
  name: 'HomeView',

  data() {
    return {
      latestProducts: []
    
    }
  },

  components: {
   
  },

  mounted() {
    this.getLatestProducts()
  },

  methods: {
  
    getLatestProducts(){
    
      axios
      .get('/api/v1/latest-products/')
      .then(response => {
        this.latestProducts = response.data
        
      })
      .catch(error => {
        console.log(error)
      })
    }
  },
}
</script>

<style scoped>
  .image{
    margin-top: -1.25rm;
    margin-left: 1.25rm;
    margin-right: -1.25rm;
  }
</style>