from django.urls import path, include
from product import views


urlpatterns = [ path('', views.LatestProductList.as_view()),
    path('latest-products/', views.LatestProductList.as_view())
]